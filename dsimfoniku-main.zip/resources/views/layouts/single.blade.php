@include('header')

<div class="h-screen flex items-center justify-center">
    @yield('content')
</div>

@include('footer')