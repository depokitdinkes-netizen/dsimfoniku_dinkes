<div class="px-3 sm:px-6 py-3">
    <div class="breadcrumbs text-sm">
        <ul>
            <li><a class="text-blue-500" href="{{ route('dashboard') }}">Dashboard</a></li>
            <li><a class="text-blue-500" href="{{ route('inspection') }}">Pilih Form Inspeksi</a></li>
            <li>Penilaian / Inspeksi</li>
        </ul>
    </div>
</div>