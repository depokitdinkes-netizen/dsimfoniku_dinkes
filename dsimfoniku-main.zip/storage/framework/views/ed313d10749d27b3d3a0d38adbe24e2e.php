<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('auth')); ?>" method="POST" class="bg-white p-10 rounded-xl">
    <?php echo csrf_field(); ?>
    <?php echo method_field('POST'); ?>

    <h1 class="text-3xl font-bold">Masuk</h1>

    <p class="mb-6 mt-3">Silakan masukkan informasi pengguna Anda.</p>

    <div class="input-group">
        <label for="email">Email</label>
        <input type="email" name="email" id="email" placeholder="Masukan Email" class="sm:min-w-80" />
    </div>
    <?php if(isset($error_email)): ?>
    <p class="mt-2 text-error text-sm"><?php echo e($error_email); ?></p>
    <?php endif; ?>

    <div class="input-group mt-4">
        <label for="password">Password</label>
        <input type="password" name="password" id="password" placeholder="Masukan Password" class="sm:min-w-80" />
    </div>
    <?php if(isset($error_password)): ?>
    <p class="mt-2 text-error text-sm"><?php echo e($error_password); ?></p>
    <?php endif; ?>

    

    <button type="submit" class="btn btn-primary mt-5 btn-block">LOGIN</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.single', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dsimfoniku-main\resources\views/pages/login.blade.php ENDPATH**/ ?>