<?php $__env->startSection('content'); ?>
<div class="p-3 sm:p-6 border-b flex items-center justify-between gap-5">
    <h1 class="font-extrabold sm:text-xl">Histori Hasil Inspeksi</h1>
    <img src="<?php echo e(asset('logo/depok-city.png')); ?>" alt="depok city" class="h-6 sm:h-9 object-cover" />
</div>

<div class="p-3 sm:p-6">
    <div class="flex justify-end gap-3 flex-wrap mb-6">
        <button class="btn btn-primary btn-outline" onclick="filter_history.showModal()">
            <i class="ri-equalizer-3-fill"></i>
            <span>FILTER</span>
            <?php if(request()->hasAny(['my', 'ft', 'kec', 'kel', 'jenis_sekolah', 'slhs_status'])): ?>
                <span class="badge badge-accent badge-sm ml-1">ON</span>
            <?php endif; ?>
        </button>
        <form method="GET" class="join">
            <!-- Preserve all current query parameters except s -->
            <?php $__currentLoopData = request()->query(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($key !== 's'): ?>
                    <?php if(is_array($value)): ?>
                        <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" name="<?php echo e($key); ?>[]" value="<?php echo e($subValue); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <input type="hidden" name="<?php echo e($key); ?>" value="<?php echo e($value); ?>">
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <button type="submit" class="btn btn-primary btn-square join-item">
                <i class="ri-search-line"></i>
            </button>
            <input type="text" name="s" class="input input-bordered join-item w-full" placeholder="Cari berdasarkan nama tempat..." value="<?php echo e(request('s')); ?>" />
        </form>

        <button class="btn btn-primary" onclick="export_history.showModal()">
            <span>RAW EXPORT</span>
            <i class="ri-upload-2-line"></i>
        </button>
    </div>

    <?php if(request()->hasAny(['my', 'ft', 'kec', 'kel', 'jenis_sekolah', 'slhs_status', 's'])): ?>
    <div class="mb-6">
        <!-- Filter Aktif Card -->
        <div class="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-4 shadow-sm">
            <div class="flex items-start gap-3">
                <div class="flex-shrink-0 w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <i class="ri-filter-3-line text-blue-600 text-lg"></i>
                </div>
                <div class="flex-1 min-w-0">
                    <div class="flex items-center justify-between mb-3">
                        <h3 class="font-semibold text-gray-800 text-sm">Filter Aktif</h3>
                        <a href="<?php echo e(route('history')); ?>" class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-blue-600 bg-blue-100 hover:bg-blue-200 rounded-lg transition-colors duration-200">
                            <i class="ri-refresh-line text-sm"></i>
                            Reset Semua
                        </a>
                    </div>
                    
                    <!-- Filter Tags -->
                    <div class="flex flex-wrap gap-2 mb-3">
                        <?php if(request('s')): ?>
                            <div class="inline-flex items-center gap-2 px-3 py-1.5 bg-white border border-blue-200 text-blue-800 rounded-lg text-sm shadow-sm">
                                <div class="flex items-center gap-1.5">
                                    <i class="ri-search-line text-blue-500"></i>
                                    <span class="font-medium text-gray-600">Pencarian:</span>
                                    <span class="font-semibold">"<?php echo e(request('s')); ?>"</span>
                                </div>
                                <a href="<?php echo e(route('history') . '?' . http_build_query(array_diff_key(request()->query(), ['s' => '']))); ?>" 
                                   class="flex-shrink-0 w-5 h-5 flex items-center justify-center bg-blue-100 hover:bg-blue-200 rounded-full transition-colors duration-200">
                                    <i class="ri-close-line text-xs text-blue-600"></i>
                                </a>
                            </div>
                        <?php endif; ?>
                        
                        <?php if(request('my')): ?>
                            <div class="inline-flex items-center gap-2 px-3 py-1.5 bg-white border border-purple-200 text-purple-800 rounded-lg text-sm shadow-sm">
                                <div class="flex items-center gap-1.5">
                                    <i class="ri-calendar-line text-purple-500"></i>
                                    <span class="font-medium text-gray-600">Bulan:</span>
                                    <span class="font-semibold"><?php echo e(\Carbon\Carbon::parse(request('my'))->format('F Y')); ?></span>
                                </div>
                                <a href="<?php echo e(route('history') . '?' . http_build_query(array_diff_key(request()->query(), ['my' => '']))); ?>" 
                                   class="flex-shrink-0 w-5 h-5 flex items-center justify-center bg-purple-100 hover:bg-purple-200 rounded-full transition-colors duration-200">
                                    <i class="ri-close-line text-xs text-purple-600"></i>
                                </a>
                            </div>
                        <?php endif; ?>
                        
                        <?php if(request('ft')): ?>
                            <?php $__currentLoopData = request('ft'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $formLabels = [
                                        'akomodasi' => 'Akomodasi',
                                        'akomodasi-lain' => 'Akomodasi Lainnya',
                                        'depot-air-minum' => 'Depot Air Minum',
                                        'tempat-olahraga' => 'Gelanggang Olahraga',
                                        'gerai-pangan-jajanan' => 'Gerai Pangan Jajanan',
                                        'gerai-jajanan-keliling' => 'Gerai Pangan Jajanan Keliling',
                                        'jasa-boga-katering' => 'Jasa Boga/Katering',
                                        'renang-pemandian' => 'Kolam Renang',
                                        'puskesmas' => 'Puskesmas',
                                        'restoran' => 'Restoran',
                                        'rumah-makan' => 'Rumah Makan',
                                        'rumah-sakit' => 'Rumah Sakit',
                                        'penyimpanan-air-hujan' => 'SAM Penyimpanan Air Hujan',
                                        'perlindungan-mata-air' => 'SAM Perlindungan Mata Air',
                                        'perpipaan-non-pdam' => 'SAM Perpipaan Non PDAM',
                                        'perpipaan' => 'SAM Perpipaan PDAM',
                                        'sumur-bor-pompa' => 'SAM Sumur Bor dengan Pompa Tangan',
                                        'sumur-gali' => 'SAM Sumur Gali dengan Kerekan',
                                        'sekolah' => 'Sekolah',
                                        'kantin' => 'Sentra Kantin',
                                        'stasiun' => 'Stasiun',
                                        'tempat-rekreasi' => 'Tempat Rekreasi',
                                    ];
                                    $formIcons = [
                                        'akomodasi' => 'ri-home-office-line',
                                        'akomodasi-lain' => 'ri-home-office-fill',
                                        'depot-air-minum' => 'ri-drinks-fill',
                                        'tempat-olahraga' => 'ri-building-4-line',
                                        'gerai-pangan-jajanan' => 'ri-store-line',
                                        'gerai-jajanan-keliling' => 'ri-store-2-line',
                                        'jasa-boga-katering' => 'ri-restaurant-line',
                                        'renang-pemandian' => 'ri-community-line',
                                        'puskesmas' => 'ri-stethoscope-line',
                                        'restoran' => 'ri-restaurant-2-line',
                                        'rumah-makan' => 'ri-home-8-line',
                                        'rumah-sakit' => 'ri-hospital-line',
                                        'penyimpanan-air-hujan' => 'ri-drop-fill',
                                        'perlindungan-mata-air' => 'ri-drop-fill',
                                        'perpipaan-non-pdam' => 'ri-drop-fill',
                                        'perpipaan' => 'ri-drop-fill',
                                        'sumur-bor-pompa' => 'ri-drop-fill',
                                        'sumur-gali' => 'ri-drop-fill',
                                        'sekolah' => 'ri-graduation-cap-line',
                                        'kantin' => 'ri-store-3-line',
                                        'stasiun' => 'ri-train-line',
                                        'tempat-rekreasi' => 'ri-sparkling-line',
                                    ];
                                    $filteredForms = array_filter(request('ft'), fn($f) => $f !== $form);
                                    $queryWithoutThisForm = array_merge(request()->query(), ['ft' => $filteredForms]);
                                    if (empty($filteredForms)) {
                                        unset($queryWithoutThisForm['ft']);
                                    }
                                ?>
                                <div class="inline-flex items-center gap-2 px-3 py-1.5 bg-white border border-emerald-200 text-emerald-800 rounded-lg text-sm shadow-sm">
                                    <div class="flex items-center gap-1.5">
                                        <i class="<?php echo e($formIcons[$form] ?? 'ri-file-line'); ?> text-emerald-500"></i>
                                        <span class="font-semibold"><?php echo e($formLabels[$form] ?? $form); ?></span>
                                    </div>
                                    <a href="<?php echo e(route('history') . '?' . http_build_query($queryWithoutThisForm)); ?>" 
                                       class="flex-shrink-0 w-5 h-5 flex items-center justify-center bg-emerald-100 hover:bg-emerald-200 rounded-full transition-colors duration-200">
                                        <i class="ri-close-line text-xs text-emerald-600"></i>
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        
                        <?php if(request('slhs_status')): ?>
                            <?php
                                $slhsLabels = [
                                    'excellent' => 'Excellent (3+ tahun)',
                                    'good' => 'Good (2+ tahun)',
                                    'caution' => 'Caution (6-12 bulan)',
                                    'warning' => 'Warning (< 6 bulan)',
                                    'critical' => 'Critical (< 1 bulan)',
                                    'expired' => 'Expired',
                                    'no-data' => 'Tidak ada data'
                                ];
                                $slhsColors = [
                                    'excellent' => ['bg' => 'bg-green-100', 'border' => 'border-green-200', 'text' => 'text-green-800', 'icon' => 'text-green-500', 'hover' => 'hover:bg-green-200'],
                                    'good' => ['bg' => 'bg-blue-100', 'border' => 'border-blue-200', 'text' => 'text-blue-800', 'icon' => 'text-blue-500', 'hover' => 'hover:bg-blue-200'],
                                    'caution' => ['bg' => 'bg-yellow-100', 'border' => 'border-yellow-200', 'text' => 'text-yellow-800', 'icon' => 'text-yellow-500', 'hover' => 'hover:bg-yellow-200'],
                                    'warning' => ['bg' => 'bg-orange-100', 'border' => 'border-orange-200', 'text' => 'text-orange-800', 'icon' => 'text-orange-500', 'hover' => 'hover:bg-orange-200'],
                                    'critical' => ['bg' => 'bg-red-100', 'border' => 'border-red-200', 'text' => 'text-red-800', 'icon' => 'text-red-500', 'hover' => 'hover:bg-red-200'],
                                    'expired' => ['bg' => 'bg-gray-100', 'border' => 'border-gray-200', 'text' => 'text-gray-800', 'icon' => 'text-gray-500', 'hover' => 'hover:bg-gray-200'],
                                    'no-data' => ['bg' => 'bg-gray-100', 'border' => 'border-gray-200', 'text' => 'text-gray-800', 'icon' => 'text-gray-500', 'hover' => 'hover:bg-gray-200']
                                ];
                                $colors = $slhsColors[request('slhs_status')] ?? $slhsColors['no-data'];
                            ?>
                            <div class="inline-flex items-center gap-2 px-3 py-1.5 bg-white <?php echo e($colors['border']); ?> <?php echo e($colors['text']); ?> rounded-lg text-sm shadow-sm">
                                <div class="flex items-center gap-1.5">
                                    <i class="ri-shield-check-line <?php echo e($colors['icon']); ?>"></i>
                                    <span class="font-medium text-gray-600">SLHS:</span>
                                    <span class="font-semibold"><?php echo e($slhsLabels[request('slhs_status')] ?? request('slhs_status')); ?></span>
                                </div>
                                <a href="<?php echo e(route('history') . '?' . http_build_query(array_diff_key(request()->query(), ['slhs_status' => '']))); ?>" 
                                   class="flex-shrink-0 w-5 h-5 flex items-center justify-center <?php echo e($colors['bg']); ?> <?php echo e($colors['hover']); ?> rounded-full transition-colors duration-200">
                                    <i class="ri-close-line text-xs <?php echo e(str_replace('text-', 'text-', $colors['icon'])); ?>"></i>
                                </a>
                            </div>
                        <?php endif; ?>
                        
                        <?php if(request('jenis_sekolah')): ?>
                            <div class="inline-flex items-center gap-2 px-3 py-1.5 bg-white border border-indigo-200 text-indigo-800 rounded-lg text-sm shadow-sm">
                                <div class="flex items-center gap-1.5">
                                    <i class="ri-school-line text-indigo-500"></i>
                                    <span class="font-medium text-gray-600">Jenis Sekolah:</span>
                                    <span class="font-semibold"><?php echo e(request('jenis_sekolah')); ?></span>
                                </div>
                                <a href="<?php echo e(route('history') . '?' . http_build_query(array_diff_key(request()->query(), ['jenis_sekolah' => '']))); ?>" 
                                   class="flex-shrink-0 w-5 h-5 flex items-center justify-center bg-indigo-100 hover:bg-indigo-200 rounded-full transition-colors duration-200">
                                    <i class="ri-close-line text-xs text-indigo-600"></i>
                                </a>
                            </div>
                        <?php endif; ?>
                        
                        <?php if(request('kec')): ?>
                            <div class="inline-flex items-center gap-2 px-3 py-1.5 bg-white border border-orange-200 text-orange-800 rounded-lg text-sm shadow-sm">
                                <div class="flex items-center gap-1.5">
                                    <i class="ri-map-pin-line text-orange-500"></i>
                                    <span class="font-medium text-gray-600">Kecamatan:</span>
                                    <span class="font-semibold"><?php echo e(request('kec')); ?></span>
                                </div>
                                <a href="<?php echo e(route('history') . '?' . http_build_query(array_diff_key(request()->query(), ['kec' => '', 'kel' => '']))); ?>" 
                                   class="flex-shrink-0 w-5 h-5 flex items-center justify-center bg-orange-100 hover:bg-orange-200 rounded-full transition-colors duration-200">
                                    <i class="ri-close-line text-xs text-orange-600"></i>
                                </a>
                            </div>
                        <?php endif; ?>
                        
                        <?php if(request('kel')): ?>
                            <?php $__currentLoopData = request('kel'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelurahan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $filteredKel = array_filter(request('kel'), fn($k) => $k !== $kelurahan);
                                    $queryWithoutThisKel = array_merge(request()->query(), ['kel' => $filteredKel]);
                                    if (empty($filteredKel)) {
                                        unset($queryWithoutThisKel['kel']);
                                    }
                                ?>
                                <div class="inline-flex items-center gap-2 px-3 py-1.5 bg-white border border-rose-200 text-rose-800 rounded-lg text-sm shadow-sm">
                                    <div class="flex items-center gap-1.5">
                                        <i class="ri-community-line text-rose-500"></i>
                                        <span class="font-medium text-gray-600">Kelurahan:</span>
                                        <span class="font-semibold"><?php echo e($kelurahan); ?></span>
                                    </div>
                                    <a href="<?php echo e(route('history') . '?' . http_build_query($queryWithoutThisKel)); ?>" 
                                       class="flex-shrink-0 w-5 h-5 flex items-center justify-center bg-rose-100 hover:bg-rose-200 rounded-full transition-colors duration-200">
                                        <i class="ri-close-line text-xs text-rose-600"></i>
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Results Counter -->
                    <div class="flex items-center justify-between pt-2 border-t border-blue-100">
                        <div class="flex items-center gap-2">
                            <div class="w-2 h-2 bg-blue-400 rounded-full"></div>
                            <span class="text-sm font-medium text-gray-700">
                                Menampilkan 
                                <span class="font-bold text-blue-600"><?php echo e(count($inspections) > 0 ? (($page_index - 1) * $dpp + 1) : 0); ?> - <?php echo e(min($page_index * $dpp, $total_records)); ?></span> 
                                dari 
                                <span class="font-bold text-blue-600"><?php echo e(number_format($total_records)); ?></span> 
                                hasil
                            </span>
                        </div>
                        
                        <?php if($total_records > 0): ?>
                        <div class="text-xs text-gray-500">
                            Halaman <?php echo e($page_index); ?> dari <?php echo e($total_pages); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="overflow-x-auto mb-2 bg-white rounded-lg">
        <table class="table table-zebra">
            <thead>
                <tr>
                    <th></th>
                    <th>Nama Tempat</th>
                    <th>Nama Pemeriksa</th>
                    <th>Skor</th>
                    <th>Tanggal Pemeriksaan</th>
                    <th>Status Operasi</th>
                    <th>Status SLHS</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php if(count($inspections) == 0): ?>
                <tr>
                    <td colspan="8" class="text-center">Tidak ada hasil inspeksi yang dapat ditampilkan</td>
                </tr>
                <?php endif; ?>
                <?php $__currentLoopData = $inspections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $inspection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($index + 1 + (($page_index - 1) * $dpp)); ?></th>
                    <td><i class="<?php echo e($inspection['icon']); ?> text-<?php echo e($inspection['color']); ?>"></i> <span><?php echo e($inspection['name']); ?></span></td>
                    <td><?php echo e($inspection['reviewer']); ?></td>
                    <td class="font-semibold"><?php echo e(number_format($inspection['score'], 0, ',', '.')); ?></td>
                    <td><?php echo e($inspection['date']); ?></td>
                    <td>
                        <?php if($inspection['operasi']): ?>
                        <p class="border-success border text-success font-medium px-3 py-1.5 rounded-full text-xs text-center">MASIH BEROPERASI</p>
                        <?php else: ?>
                        <p class="border-error border text-error font-medium px-1.5 py-1 rounded-full text-xs text-center">TIDAK BEROPERASI</p>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if (isset($component)) { $__componentOriginal2cb09917c463a753a5d3502338d96dfa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2cb09917c463a753a5d3502338d96dfa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status.slhs-badge','data' => ['slhsExpireDate' => $inspection['slhs_expire_date'] ?? null,'slhsIssuedDate' => $inspection['slhs_issued_date'] ?? null,'showTooltip' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status.slhs-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['slhsExpireDate' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($inspection['slhs_expire_date'] ?? null),'slhsIssuedDate' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($inspection['slhs_issued_date'] ?? null),'showTooltip' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2cb09917c463a753a5d3502338d96dfa)): ?>
<?php $attributes = $__attributesOriginal2cb09917c463a753a5d3502338d96dfa; ?>
<?php unset($__attributesOriginal2cb09917c463a753a5d3502338d96dfa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2cb09917c463a753a5d3502338d96dfa)): ?>
<?php $component = $__componentOriginal2cb09917c463a753a5d3502338d96dfa; ?>
<?php unset($__componentOriginal2cb09917c463a753a5d3502338d96dfa); ?>
<?php endif; ?>
                    </td>
                    <td class="flex gap-1.5">
                        <?php if(auth()->guard()->check()): ?>
                        <?php if(Auth::user()->role != "USER"): ?>
                        <div class="tooltip tooltip-warning" data-tip="Ubah Informasi / Penilaian">
                            <a href="<?php echo e($inspection['sud'] . '/edit'); ?>" class="btn btn-warning btn-square">
                                <i class="ri-edit-fill"></i>
                            </a>
                        </div>
                        <?php endif; ?>
                        <?php if(Auth::user()->role == "SUPERADMIN"): ?>
                        <form id="deleteForm<?php echo e($index); ?>" action="<?php echo e(url($inspection['sud'])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>

                            <div class="tooltip tooltip-error" data-tip="Hapus Hasil Inspeksi">
                                <button type="button" class="btn btn-error btn-outline btn-square" onclick="showDeleteConfirmation('<?php echo e($inspection['name']); ?>', <?php echo e($index); ?>)">
                                    <i class="ri-delete-bin-6-line"></i>
                                </button>
                            </div>
                        </form>
                        <?php endif; ?>
                        <?php endif; ?>

                        <div class="tooltip" data-tip="Lihat Hasil Inspeksi">
                            <a href="<?php echo e($inspection['sud']); ?>" class="btn btn-neutral">
                                <i class="ri-info-i"></i>
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>

    <div class="flex gap-3 mt-5 items-center justify-end">
        <?php if(auth()->guard()->check()): ?>
        <?php if(Auth::user()->role == "SUPERADMIN"): ?>
        <a href="<?php echo e(route('archived')); ?>" class="btn btn-primary btn-outline">ARCHIVED INSPEKSI</a>
        <?php endif; ?>
        <?php endif; ?>

        <div class="join">
            <?php if($page_index != 1): ?>
            <a href="<?php echo e(route('history') . '?' . http_build_query(array_merge(request()->query(), ['p' => (int) $page_index - 1]))); ?>" class="join-item btn rounded">
                <i class="ri-arrow-left-s-line"></i>
            </a>
            <a href="<?php echo e(route('history') . '?' . http_build_query(array_merge(request()->query(), ['p' => (int) $page_index - 1]))); ?>" class="join-item btn rounded">
                <?php echo e((int) $page_index - 1); ?>

            </a>
            <?php endif; ?>
            <button type="button" class="join-item btn rounded btn-active"><?php echo e($page_index); ?></button>
            <?php if($page_index != $total_pages && $total_pages != 0): ?>
            <a href="<?php echo e(route('history') . '?' . http_build_query(array_merge(request()->query(), ['p' => (int) $page_index + 1]))); ?>" class="join-item btn rounded">
                <?php echo e((int) $page_index + 1); ?>

            </a>
            <a href="<?php echo e(route('history') . '?' . http_build_query(array_merge(request()->query(), ['p' => (int) $page_index + 1]))); ?>" class="join-item btn rounded">
                <i class="ri-arrow-right-s-line"></i>
            </a>
            <?php endif; ?>
        </div>
        <form action="<?php echo e(route('history')); ?>" class="join">
            <!-- Preserve all current query parameters except dpp -->
            <?php $__currentLoopData = request()->query(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($key !== 'dpp'): ?>
                    <?php if(is_array($value)): ?>
                        <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" name="<?php echo e($key); ?>[]" value="<?php echo e($subValue); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <input type="hidden" name="<?php echo e($key); ?>" value="<?php echo e($value); ?>">
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <select class="select select-bordered join-item" name="dpp">
                <option value="5" <?php if($dpp==5): ?> selected <?php endif; ?>>5</option>
                <option value="15" <?php if($dpp==15): ?> selected <?php endif; ?>>15</option>
                <option value="25" <?php if($dpp==25): ?> selected <?php endif; ?>>25</option>
            </select>
            <button type="submit" class="btn btn-neutral join-item rounded">Set</button>
        </form>
    </div>
</div>

<?php if (isset($component)) { $__componentOriginal2b879a320b4c7309931c926bc74c6b94 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2b879a320b4c7309931c926bc74c6b94 = $attributes; } ?>
<?php $component = App\View\Components\Modal\FilterHistory::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal.filter-history'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modal\FilterHistory::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2b879a320b4c7309931c926bc74c6b94)): ?>
<?php $attributes = $__attributesOriginal2b879a320b4c7309931c926bc74c6b94; ?>
<?php unset($__attributesOriginal2b879a320b4c7309931c926bc74c6b94); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b879a320b4c7309931c926bc74c6b94)): ?>
<?php $component = $__componentOriginal2b879a320b4c7309931c926bc74c6b94; ?>
<?php unset($__componentOriginal2b879a320b4c7309931c926bc74c6b94); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal0a0e5c144b8765197f1f5213dbdfe81f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0a0e5c144b8765197f1f5213dbdfe81f = $attributes; } ?>
<?php $component = App\View\Components\Modal\ExportHistory::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal.export-history'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modal\ExportHistory::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0a0e5c144b8765197f1f5213dbdfe81f)): ?>
<?php $attributes = $__attributesOriginal0a0e5c144b8765197f1f5213dbdfe81f; ?>
<?php unset($__attributesOriginal0a0e5c144b8765197f1f5213dbdfe81f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0a0e5c144b8765197f1f5213dbdfe81f)): ?>
<?php $component = $__componentOriginal0a0e5c144b8765197f1f5213dbdfe81f; ?>
<?php unset($__componentOriginal0a0e5c144b8765197f1f5213dbdfe81f); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginaldc6ea9e6cb99ae67e12910a2898ef296 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc6ea9e6cb99ae67e12910a2898ef296 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal.confirmation','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal.confirmation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc6ea9e6cb99ae67e12910a2898ef296)): ?>
<?php $attributes = $__attributesOriginaldc6ea9e6cb99ae67e12910a2898ef296; ?>
<?php unset($__attributesOriginaldc6ea9e6cb99ae67e12910a2898ef296); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc6ea9e6cb99ae67e12910a2898ef296)): ?>
<?php $component = $__componentOriginaldc6ea9e6cb99ae67e12910a2898ef296; ?>
<?php unset($__componentOriginaldc6ea9e6cb99ae67e12910a2898ef296); ?>
<?php endif; ?>

<script>
    function showDeleteConfirmation(inspectionName, formIndex) {
        showDeleteConfirmationModal(
            'Hapus Hasil Inspeksi',
            `Apakah Anda yakin ingin menghapus hasil inspeksi "${inspectionName}"? Data yang dihapus tidak dapat dikembalikan.`,
            function() {
                document.getElementById('deleteForm' + formIndex).submit();
            }
        );
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dsimfoniku-main\resources\views/pages/history/index.blade.php ENDPATH**/ ?>