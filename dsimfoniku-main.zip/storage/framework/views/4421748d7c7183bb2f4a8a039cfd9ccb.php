<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal65aba58a67e01afa10c5e7cfec0b6eab = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal65aba58a67e01afa10c5e7cfec0b6eab = $attributes; } ?>
<?php $component = App\View\Components\Section\PageHeader::resolve(['title' => 'Inspeksi / Penilaian Rumah Sakit'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('section.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Section\PageHeader::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal65aba58a67e01afa10c5e7cfec0b6eab)): ?>
<?php $attributes = $__attributesOriginal65aba58a67e01afa10c5e7cfec0b6eab; ?>
<?php unset($__attributesOriginal65aba58a67e01afa10c5e7cfec0b6eab); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal65aba58a67e01afa10c5e7cfec0b6eab)): ?>
<?php $component = $__componentOriginal65aba58a67e01afa10c5e7cfec0b6eab; ?>
<?php unset($__componentOriginal65aba58a67e01afa10c5e7cfec0b6eab); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginald1b1765e02c85cb2002d173d4c9c8d97 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald1b1765e02c85cb2002d173d4c9c8d97 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb\CreateInspection::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb.create-inspection'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Breadcrumb\CreateInspection::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald1b1765e02c85cb2002d173d4c9c8d97)): ?>
<?php $attributes = $__attributesOriginald1b1765e02c85cb2002d173d4c9c8d97; ?>
<?php unset($__attributesOriginald1b1765e02c85cb2002d173d4c9c8d97); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald1b1765e02c85cb2002d173d4c9c8d97)): ?>
<?php $component = $__componentOriginald1b1765e02c85cb2002d173d4c9c8d97; ?>
<?php unset($__componentOriginald1b1765e02c85cb2002d173d4c9c8d97); ?>
<?php endif; ?>

<form action="<?php echo e(route('rumah-sakit.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('POST'); ?>
    <!-- INFORMASI UMUM -->
    <div class="px-3 pb-3 sm:px-6 sm:pb-6">
        <div class="bg-white p-6 sm:p-8 rounded-xl">
            <h1 class="font-bold text-        if (!$('input[name="pengisian-dsmiling"]:checked').length) {
            $('input[name="pengisian-dsmiling"][value="Ya"]').prop('checked', true);
        }
    });
    
    // Handle option selection for fields with duplicate values
    $('input[name="1002"], input[name="f9003"]').on('change', function() {
        const fieldName = $(this).attr('name');
        const selectedValue = $(this).val();
        
        // Find the corresponding hidden field with option ID for the selected radio button
        const parentLabel = $(this).closest('label');
        const hiddenField = parentLabel.find('input[type="hidden"][name^="' + fieldName + '_selected_id_"]');
        
        if (hiddenField.length) {
            // Remove any existing selected_id field and add the new one
            $('input[name="' + fieldName + '_selected_id"]').remove();
            $('<input>').attr({
                type: 'hidden',
                name: fieldName + '_selected_id',
                value: hiddenField.val()
            }).appendTo('form');
        }
    });

    // Initialize default selected IDs on page load
    $('input[name="1002"]:checked, input[name="f9003"]:checked').each(function() {
        const fieldName = $(this).attr('name');
        const parentLabel = $(this).closest('label');
        const hiddenField = parentLabel.find('input[type="hidden"][name^="' + fieldName + '_selected_id_"]');
        
        if (hiddenField.length) {
            $('input[name="' + fieldName + '_selected_id"]').remove();
            $('<input>').attr({
                type: 'hidden',
                name: fieldName + '_selected_id',
                value: hiddenField.val()
            }).appendTo('form');
        }
    });
});Informasi Umum</h1>
            <hr class="my-5" />
            <div class="grid grid-flow-row md:grid-cols-2 gap-5">
                <?php $__currentLoopData = $informasi_umum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form_input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php switch($form_input['name']):
                case ('instansi-pemeriksa'): ?>
                <?php if (isset($component)) { $__componentOriginal401bfeae30a7c38498518b4d7597bfc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal401bfeae30a7c38498518b4d7597bfc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input.instansi-pemeriksa.create','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input.instansi-pemeriksa.create'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal401bfeae30a7c38498518b4d7597bfc2)): ?>
<?php $attributes = $__attributesOriginal401bfeae30a7c38498518b4d7597bfc2; ?>
<?php unset($__attributesOriginal401bfeae30a7c38498518b4d7597bfc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal401bfeae30a7c38498518b4d7597bfc2)): ?>
<?php $component = $__componentOriginal401bfeae30a7c38498518b4d7597bfc2; ?>
<?php unset($__componentOriginal401bfeae30a7c38498518b4d7597bfc2); ?>
<?php endif; ?>
                <?php break; ?>

                <?php case ('kecamatan'): ?>
                <div class="input-group">
                    <label for="kec"><?php echo e($form_input['label']); ?></label>
                    <select name="<?php echo e($form_input['name']); ?>" id="kec" class="select select-bordered" required>
                        <option value="">Pilih Kecamatan</option>
                    </select>
                </div>
                <?php break; ?>

                <?php case ('kelurahan'): ?>
                <div class="input-group">
                    <label for="kel"><?php echo e($form_input['label']); ?></label>
                    <select name="<?php echo e($form_input['name']); ?>" id="kel" class="select select-bordered" required>
                        <option value="">Pilih Kelurahan</option>
                    </select>
                </div>
                <?php break; ?>

                <?php case ('status-operasi'): ?>
                <div class="input-group">
                    <label for="status-operasi"><?php echo e($form_input['label']); ?></label>
                    <select name="<?php echo e($form_input['name']); ?>" id="status-operasi" class="select select-bordered" required>
                        <option value="" disabled selected>Pilih Status</option>
                        <option value="1">Masih Beroperasi</option>
                        <option value="0">Tidak Beroperasi</option>
                    </select>
                </div>
                <?php break; ?>

                <?php case ('koordinat'): ?>
                <div class="input-group">
                    <label for="<?php echo e($form_input['name']); ?>"><?php echo e($form_input['label']); ?></label>
                    <div class="join">
                        <input type="<?php echo e($form_input['type']); ?>" id="koordinat" name="koordinat" class="join-item w-full" placeholder="-6.324667, 106.891268" required />
                        <button onclick="get_lat_long.showModal()" type="button" class="join-item btn btn-neutral">
                            <i class="ri-search-2-line"></i>
                        </button>
                    </div>
                </div>
                <?php break; ?>

                <?php case ('kelas'): ?>
                <div class="input-group">
                    <label for="kelas"><?php echo e($form_input['label']); ?></label>
                    <select name="<?php echo e($form_input['name']); ?>" id="kelas" class="select select-bordered" required>
                        <option value="" disabled selected>Pilih Kelas</option>
                        <option value="A">A</option>
                        <option value="B">B</option>
                        <option value="C">C</option>
                    </select>
                </div>
                <?php break; ?>

                <?php case ('dokumen-rintek-tps-b3'): ?>
                <div class="input-group">
                    <label><?php echo e($form_input['label']); ?></label>
                    <div class="flex gap-4">
                        <label class="flex items-center gap-2">
                            <input type="radio" name="<?php echo e($form_input['name']); ?>" class="radio checked:bg-primary" value="Tidak" checked />
                            <span>Tidak</span>
                        </label>
                        <label class="flex items-center gap-2">
                            <input type="radio" name="<?php echo e($form_input['name']); ?>" class="radio checked:bg-primary" value="Ya" />
                            <span>Ya</span>
                        </label>
                    </div>
                </div>
                <?php break; ?>

                <?php case ('dokumen-pertek-ipal'): ?>
                <div class="input-group">
                    <label><?php echo e($form_input['label']); ?></label>
                    <div class="flex gap-4">
                        <label class="flex items-center gap-2">
                            <input type="radio" name="<?php echo e($form_input['name']); ?>" class="radio checked:bg-primary" value="Tidak" checked />
                            <span>Tidak</span>
                        </label>
                        <label class="flex items-center gap-2">
                            <input type="radio" name="<?php echo e($form_input['name']); ?>" class="radio checked:bg-primary" value="Ya" />
                            <span>Ya</span>
                        </label>
                    </div>
                </div>
                <?php break; ?>

                <?php case ('pengisian-sikelim'): ?>
                <div class="input-group">
                    <label><?php echo e($form_input['label']); ?></label>
                    <div class="flex gap-4">
                        <label class="flex items-center gap-2">
                            <input type="radio" name="<?php echo e($form_input['name']); ?>" class="radio checked:bg-primary" value="Tidak" />
                            <span>Tidak</span>
                        </label>
                        <label class="flex items-center gap-2">
                            <input type="radio" name="<?php echo e($form_input['name']); ?>" class="radio checked:bg-primary" value="Ya" checked />
                            <span>Ya</span>
                        </label>
                    </div>
                </div>
                <?php break; ?>

                <?php case ('pengisian-dsmiling'): ?>
                <div class="input-group">
                    <label><?php echo e($form_input['label']); ?></label>
                    <div class="flex gap-4">
                        <label class="flex items-center gap-2">
                            <input type="radio" name="<?php echo e($form_input['name']); ?>" class="radio checked:bg-primary" value="Tidak" />
                            <span>Tidak</span>
                        </label>
                        <label class="flex items-center gap-2">
                            <input type="radio" name="<?php echo e($form_input['name']); ?>" class="radio checked:bg-primary" value="Ya" checked />
                            <span>Ya</span>
                        </label>
                    </div>
                </div>
                <?php break; ?>

                <?php case ('nomor-dokumen-rintek-tps-b3'): ?>
                <div class="input-group" id="nomor-dokumen-rintek-tps-b3-group" style="display: none;">
                    <label for="<?php echo e($form_input['name']); ?>"><?php echo e($form_input['label']); ?></label>
                    <input type="text" id="<?php echo e($form_input['name']); ?>" name="<?php echo e($form_input['name']); ?>" placeholder="Masukkan nomor dokumen..." />
                </div>
                <?php break; ?>

                <?php case ('nomor-dokumen-pertek-ipal'): ?>
                <div class="input-group" id="nomor-dokumen-pertek-ipal-group" style="display: none;">
                    <label for="<?php echo e($form_input['name']); ?>"><?php echo e($form_input['label']); ?></label>
                    <input type="text" id="<?php echo e($form_input['name']); ?>" name="<?php echo e($form_input['name']); ?>" placeholder="Masukkan nomor dokumen..." />
                </div>
                <?php break; ?>

                <?php case ('alasan-sikelim'): ?>
                <div class="input-group" id="alasan-sikelim-group" style="display: none;">
                    <label for="<?php echo e($form_input['name']); ?>"><?php echo e($form_input['label']); ?></label>
                    <input type="text" id="<?php echo e($form_input['name']); ?>" name="<?php echo e($form_input['name']); ?>" placeholder="Masukkan alasan..." />
                </div>
                <?php break; ?>

                <?php case ('alasan-dsmiling'): ?>
                <div class="input-group" id="alasan-dsmiling-group" style="display: none;">
                    <label for="<?php echo e($form_input['name']); ?>"><?php echo e($form_input['label']); ?></label>
                    <input type="text" id="<?php echo e($form_input['name']); ?>" name="<?php echo e($form_input['name']); ?>" placeholder="Masukkan alasan..." />
                </div>
                <?php break; ?>

                <?php default: ?>
                <div class="input-group">
                    <label for="<?php echo e($form_input['name']); ?>"><?php echo e($form_input['label']); ?></label>
                    <input type="<?php echo e($form_input['type']); ?>" id="<?php echo e($form_input['name']); ?>" name="<?php echo e($form_input['name']); ?>" required />
                </div>
                <?php endswitch; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <!-- FORM PENILAIAN -->
    <div class="px-3 pb-3 sm:px-6 sm:pb-6 flex flex-wrap lg:flex-nowrap gap-5">
        <div class="bg-white flex-grow pb-4 rounded-xl">
            <div class="p-6 sm:p-8">
                <h1 class="font-bold text-xl">Formulir Penilaian</h1>
            </div>

            <?php $__currentLoopData = $form_penilaian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $form_input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php switch($form_input['type']):

            case ('h2'): ?>
            <div class="text-white bg-black/40 px-6 sm:px-8 py-4 mb-6 <?php if($index > 0): ?> mt-10 <?php endif; ?>">
                <h2 class="font-semibold text-lg relative"><?php echo e($form_input['label']); ?></h2>
            </div>

            <?php break; ?>

            <?php case ('h3'): ?>
            <div id="<?php echo e(strtolower(str_replace(' ', '-', $form_input['label']))); ?>" class="px-6 sm:px-8 pt-2">
                <h3 class="badge badge-lg badge-neutral badge-outline font-semibold mb-5 mt-6"><?php echo e($form_input['label']); ?></h3>
            </div>
            <?php break; ?>

            <?php case ('h4'): ?>
            <div class="px-6 sm:px-8 pb-3 mt-4">
                <h4 class="text-base underline underline-offset-8"><?php echo e($form_input['label']); ?> :</h4>
            </div>
            <?php break; ?>

            <?php case ('selectc'): ?>
            <div class="px-3 sm:px-8">
                <div class="p-4 border rounded mb-3">
                    <div class="flex flex-col-reverse sm:flex-row justify-between gap-2 font-medium">
                        <label for="<?php echo e($form_input['name']); ?>"><?php echo e($form_input['label']); ?></label>
                        <div>
                            <span class="badge badge-outline badge-ghost">×<?php echo e($form_input['bobot']); ?></span>
                            <span class="badge badge-outline badge-error">+<?php echo e($form_input['sesuai']); ?></span>
                        </div>
                    </div>
                    <hr class="mt-3 mb-2" />
                    <div class="flex gap-5">
                        <div class="form-control">
                            <label class="label cursor-pointer justify-start gap-2">
                                <input type="radio" name="<?php echo e($form_input['name']); ?>" class="radio checked:bg-primary" value="<?php echo e($form_input['option'][0]['value']); ?>" checked />
                                <span class="label-text"><?php echo e($form_input['option'][0]['label']); ?></span>
                            </label>
                        </div>
                        <div class="form-control">
                            <label class="label cursor-pointer justify-start gap-2">
                                <input type="radio" name="<?php echo e($form_input['name']); ?>" class="radio checked:bg-error" value="<?php echo e($form_input['option'][1]['value']); ?>" />
                                <span class="label-text"><?php echo e($form_input['option'][1]['label']); ?></span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <?php break; ?>

            <?php case ('selects'): ?>
            <div class="px-3 sm:px-8">
                <div class="p-4 border rounded mb-3">
                    <div class="flex flex-col-reverse sm:flex-row justify-between gap-2 font-medium">
                        <label for="<?php echo e($form_input['name']); ?>"><?php echo e($form_input['label']); ?></label>
                        <div>
                            <span class="badge badge-outline badge-ghost">×<?php echo e($form_input['bobot']); ?></span>
                        </div>
                    </div>
                    <hr class="mt-3 mb-2" />
                    <?php $__currentLoopData = $form_input['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-control">
                        <label class="label cursor-pointer justify-start gap-2">
                            <?php
                                // For fields with bobot = 0, use original option value
                                $actualValue = $form_input['bobot'] == 0 ? $option['value'] : $form_input['bobot'] * $option['value'];
                                // For create form, select default based on highest value or specific defaults
                                $isDefaultSelected = false;
                                
                                // Special default handling for specific fields
                                if ($form_input['name'] == '1002' && isset($option['id']) && $option['id'] == '1002_a') {
                                    $isDefaultSelected = true; // First option for 1002
                                } elseif ($form_input['name'] == 'f9003' && isset($option['id']) && $option['id'] == 'f9003_a') {
                    $isDefaultSelected = true; // First option for f9003
                } elseif (in_array($form_input['name'], ['f1001', 'f1003', 'f1004', 'f2002', 'f3001', 'f3002', 'f4001', 'f4002', 'f4005', 'f5002', 'f7001', 'f7002', 'f7003', 'f7004', 'f7005', 'f9002']) && $loop->first) {
                    $isDefaultSelected = true; // First option for problematic selects fields
                } elseif (!in_array($form_input['name'], ['1002', 'f9003', 'f1001', 'f1003', 'f1004', 'f2002', 'f3001', 'f3002', 'f4001', 'f4002', 'f4005', 'f5002', 'f7001', 'f7002', 'f7003', 'f7004', 'f7005', 'f9002']) && $loop->first) {
                                    $isDefaultSelected = true; // First option for all other selects fields
                                }
                            ?>
                            <input type="radio" name="<?php echo e($form_input['name']); ?>" class="radio checked:bg-primary" value="<?php echo e($actualValue); ?>" <?php if($isDefaultSelected): ?> checked <?php endif; ?> />
                            <span class="label-text"><?php echo e($option['label']); ?></span>
                            <span class="badge badge-outline badge-error">+<?php echo e($option['value']); ?></span>
                            
                            <?php if(isset($option['id']) && in_array($form_input['name'], ['1002', 'f9003'])): ?>
                                <input type="hidden" name="<?php echo e($form_input['name']); ?>_selected_id_<?php echo e($loop->index); ?>" value="<?php echo e($option['id']); ?>" />
                            <?php endif; ?>
                        </label>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    
                    <?php if(in_array($form_input['name'], ['f1006', 'f1007', '6001e'])): ?>
                        <div class="mt-3" id="<?php echo e($form_input['name']); ?>_lainnya_container" style="display: none;">
                            <input type="text" name="<?php echo e($form_input['name']); ?>_lainnya" class="input input-bordered w-full" placeholder="Sebutkan..." />
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php break; ?>

            <?php case ('input'): ?>
            <?php case ('date'): ?>
            <?php case ('text'): ?>
            <?php case ('number'): ?>
            <?php case ('email'): ?>
            <div class="px-3 sm:px-8">
                <div class="p-4 border rounded mb-3">
                    <div class="input-group">
                        <label for="<?php echo e($form_input['name']); ?>"><?php echo e($form_input['label']); ?></label>
                        <input type="<?php echo e($form_input['type']); ?>" id="<?php echo e($form_input['name']); ?>" name="<?php echo e($form_input['name']); ?>" placeholder="<?php echo e($form_input['label']); ?>" />
                    </div>
                </div>
            </div>
            <?php break; ?>

            <?php case ('textarea'): ?>
            <div class="px-3 sm:px-8">
                <div class="p-4 border rounded mb-3">
                    <div class="input-group">
                        <label for="<?php echo e($form_input['name']); ?>"><?php echo e($form_input['label']); ?></label>
                        <textarea id="<?php echo e($form_input['name']); ?>" name="<?php echo e($form_input['name']); ?>" class="resize-none h-32" placeholder="<?php echo e($form_input['label']); ?>"></textarea>
                    </div>
                </div>
            </div>
            <?php break; ?>

            <?php default: ?>

            <?php endswitch; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <!-- Informasi Tambahan Section -->
            <div class="px-6 sm:px-8 pt-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4 border-b-2 border-gray-200 pb-2">Informasi Tambahan</h2>
            </div>

            <div id="pelaporan-elektronik" class="px-6 sm:px-8 pt-2">
                <label for="pelaporan-elektronik" class="badge badge-lg badge-neutral badge-outline font-semibold mb-5 mt-6">Pelaporan Elektronik</label>
            </div>

            <div class="px-6 sm:px-8">
                <div class="input-group">
                    <textarea name="pelaporan-elektronik" id="pelaporan-elektronik" class="resize-none h-52" required placeholder="Catatan mengenai elektronik (jika kosong isi &quot;-&quot;)" required></textarea>
                </div>
            </div>

            <div id="pengamanan-radiasi" class="px-6 sm:px-8 pt-2">
                <label for="pengamanan-radiasi" class="badge badge-lg badge-neutral badge-outline font-semibold mb-5 mt-6">Pengamanan Radiasi</label>
            </div>

            <div class="px-6 sm:px-8">
                <div class="input-group">
                    <textarea name="pengamanan-radiasi" id="pengamanan-radiasi" class="resize-none h-52" required placeholder="Catatan mengenai pengamanan radiasi (jika kosong isi &quot;-&quot;)" required></textarea>
                </div>
            </div>

            <div id="penyehatan-air-hemodiolisa" class="px-6 sm:px-8 pt-2">
                <label for="penyehatan-air-hemodiolisa" class="badge badge-lg badge-neutral badge-outline font-semibold mb-5 mt-6">Penyehatan Air Hemodiolisa</label>
            </div>

            <div class="px-6 sm:px-8">
                <div class="input-group">
                    <textarea name="penyehatan-air-hemodiolisa" id="penyehatan-air-hemodiolisa" class="resize-none h-52" required placeholder="Catatan mengenai penyehatan air hemodiolisa (jika kosong isi &quot;-&quot;)" required></textarea>
                </div>
            </div>

            <div id="catatan-lain" class="px-6 sm:px-8 pt-2">
                <label for="catatan-lain" class="badge badge-lg badge-neutral badge-outline font-semibold mb-5 mt-6">Hasil IKL</label>
            </div>

            <div class="px-6 sm:px-8">
                <div class="input-group">
                    <textarea name="catatan-lain" id="catatan-lain" class="resize-none h-52" required placeholder="Catatan mengenai hasil inpeksi lingkungan kesehatan..."></textarea>
                </div>
            </div>

            <div id="rencana-tindak-lanjut" class="px-6 sm:px-8 pt-2">
                <label for="rencana-tindak-lanjut" class="badge badge-lg badge-neutral badge-outline font-semibold mb-5 mt-6">Rencana Tindak Lanjut</label>
            </div>

            <div class="px-6 sm:px-8">
                <div class="input-group">
                    <textarea name="rencana-tindak-lanjut" id="rencana-tindak-lanjut" class="resize-none h-52" required placeholder="Rencana untuk tindak lanjut kedepannya setelah inpeksi lingkungan kesehatan..."></textarea>
                </div>
            </div>
        </div>

        <div class="sticky top-5 h-fit min-w-72 w-full lg:w-fit">
            <div class="bg-white p-6 max-h-[30rem] overflow-y-auto hidden lg:block mb-5 rounded-xl">
                <?php $__currentLoopData = $form_penilaian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $heading): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php switch($heading['type']):
                case ('h2'): ?>
                <p class="font-semibold text-sm <?php if($index > 0): ?>
                mt-5
            <?php endif; ?>"><?php echo e($heading['label']); ?></p>
                <?php break; ?>
                <?php case ('h3'): ?>
                <a href="#<?php echo e(strtolower(str_replace(' ', '-', $heading['label']))); ?>" class="text-blue-500 text-sm my-2 block ml-2 underline "><?php echo e($heading['label']); ?></a>
                <?php break; ?>
                <?php endswitch; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <a href="#pelaporan-elektronik" class="text-blue-500 text-sm my-2 block ml-2 underline">Pelaporan Elektronik</a>
                <a href="#pengamanan-radiasi" class="text-blue-500 text-sm my-2 block ml-2 underline">Pengamanan Radiasi</a>
                <a href="#penyehatan-air-hemodiolisa" class="text-blue-500 text-sm my-2 block ml-2 underline">Penyehatan Air Hemodiolisa</a>
                <a href="#catatan-lain" class="text-blue-500 text-sm my-2 block ml-2 underline">Hasil IKL</a>
                <a href="#rencana-tindak-lanjut" class="text-blue-500 text-sm my-2 block ml-2 underline">Rencana Tindak Lanjut</a>
            </div>
            <button onclick="reminder_before_submit.showModal()" type="button" class="btn btn-primary btn-block">SUBMIT PENILAIAN</button>

            <?php if (isset($component)) { $__componentOriginal1d7c8e2a48a9d31f98dda8afd13a2d7b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1d7c8e2a48a9d31f98dda8afd13a2d7b = $attributes; } ?>
<?php $component = App\View\Components\Modal\ReminderBeforeSubmit::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal.reminder-before-submit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modal\ReminderBeforeSubmit::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1d7c8e2a48a9d31f98dda8afd13a2d7b)): ?>
<?php $attributes = $__attributesOriginal1d7c8e2a48a9d31f98dda8afd13a2d7b; ?>
<?php unset($__attributesOriginal1d7c8e2a48a9d31f98dda8afd13a2d7b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1d7c8e2a48a9d31f98dda8afd13a2d7b)): ?>
<?php $component = $__componentOriginal1d7c8e2a48a9d31f98dda8afd13a2d7b; ?>
<?php unset($__componentOriginal1d7c8e2a48a9d31f98dda8afd13a2d7b); ?>
<?php endif; ?>
        </div>

    </div>
</form>

<?php if (isset($component)) { $__componentOriginal4f79666d4f834fb25649c1efa5f462ef = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4f79666d4f834fb25649c1efa5f462ef = $attributes; } ?>
<?php $component = App\View\Components\Modal\GetLatLong::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal.get-lat-long'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modal\GetLatLong::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4f79666d4f834fb25649c1efa5f462ef)): ?>
<?php $attributes = $__attributesOriginal4f79666d4f834fb25649c1efa5f462ef; ?>
<?php unset($__attributesOriginal4f79666d4f834fb25649c1efa5f462ef); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f79666d4f834fb25649c1efa5f462ef)): ?>
<?php $component = $__componentOriginal4f79666d4f834fb25649c1efa5f462ef; ?>
<?php unset($__componentOriginal4f79666d4f834fb25649c1efa5f462ef); ?>
<?php endif; ?>

<script>
// Auto-calculate on page load if issued date already filled
document.addEventListener('DOMContentLoaded', function() {
    // Conditional fields logic
    
    // Dokumen Rintek TPS B3
    $('input[name="dokumen-rintek-tps-b3"]').change(function() {
        if ($(this).val() == 'Ya') { // Ya
            $('#nomor-dokumen-rintek-tps-b3-group').show();
            $('#nomor-dokumen-rintek-tps-b3').attr('required', true);
        } else { // Tidak
            $('#nomor-dokumen-rintek-tps-b3-group').hide();
            $('#nomor-dokumen-rintek-tps-b3').attr('required', false);
            $('#nomor-dokumen-rintek-tps-b3').val('');
        }
    });
    
    // Dokumen Pertek IPAL
    $('input[name="dokumen-pertek-ipal"]').change(function() {
        if ($(this).val() == 'Ya') { // Ya
            $('#nomor-dokumen-pertek-ipal-group').show();
            $('#nomor-dokumen-pertek-ipal').attr('required', true);
        } else { // Tidak
            $('#nomor-dokumen-pertek-ipal-group').hide();
            $('#nomor-dokumen-pertek-ipal').attr('required', false);
            $('#nomor-dokumen-pertek-ipal').val('');
        }
    });
    
    // Pengisian SIKELIM
    $('input[name="pengisian-sikelim"]').change(function() {
        if ($(this).val() == 'Tidak') { // Tidak
            $('#alasan-sikelim-group').show();
            $('#alasan-sikelim').attr('required', true);
        } else { // Ya
            $('#alasan-sikelim-group').hide();
            $('#alasan-sikelim').attr('required', false);
            $('#alasan-sikelim').val('');
        }
    });
    
    // Pengisian DSMILING
    $('input[name="pengisian-dsmiling"]').change(function() {
        if ($(this).val() == 'Tidak') { // Tidak
            $('#alasan-dsmiling-group').show();
            $('#alasan-dsmiling').attr('required', true);
        } else { // Ya
            $('#alasan-dsmiling-group').hide();
            $('#alasan-dsmiling').attr('required', false);
            $('#alasan-dsmiling').val('');
        }
    });
    
    // Conditional logic for f1005, f1006, f1007
    function toggleF1006F1007() {
        const f1005Value = $('input[name="f1005"]:checked').val();
        const f1006Container = $('input[name="f1006"]').closest('.px-3');
        const f1007Container = $('input[name="f1007"]').closest('.px-3');
        
        if (f1005Value === 'Ya') { // Ya
            f1006Container.show();
            f1007Container.show();
        } else { // Tidak
            f1006Container.hide();
            f1007Container.hide();
            // Reset values when hidden
            $('input[name="f1006"]').prop('checked', false);
            $('input[name="f1007"]').prop('checked', false);
        }
    }
    
    // Initially hide f1006 and f1007
    $('input[name="f1006"]').closest('.px-3').hide();
    $('input[name="f1007"]').closest('.px-3').hide();
    
    // Bind change event to f1005
    $('input[name="f1005"]').change(toggleF1006F1007);
    
    // Check initial state
    toggleF1006F1007();
    
    // JavaScript untuk menangani pilihan 'Lainnya...'
    function handleLainnyaOption(fieldName) {
        const selectedValue = $('input[name="' + fieldName + '"]:checked').val();
        const lainnyaContainer = $('#' + fieldName + '_lainnya_container');
        
        if (selectedValue === 'Lainnya') {
            lainnyaContainer.show();
        } else {
            lainnyaContainer.hide();
            $('input[name="' + fieldName + '_lainnya"]').val('');
        }
    }
    
    // Bind change events untuk f1006, f1007, dan 6001e
    ['f1006', 'f1007', '6001e'].forEach(function(fieldName) {
        $('input[name="' + fieldName + '"]').change(function() {
            handleLainnyaOption(fieldName);
        });
        
        // Check initial state
        handleLainnyaOption(fieldName);
    });
    
    // Ensure default values are set before form submission
    $('form').on('submit', function(e) {
        // Set default values if no radio button is selected
        if (!$('input[name="dokumen-rintek-tps-b3"]:checked').length) {
            $('input[name="dokumen-rintek-tps-b3"][value="Tidak"]').prop('checked', true);
        }
        if (!$('input[name="dokumen-pertek-ipal"]:checked').length) {
            $('input[name="dokumen-pertek-ipal"][value="Tidak"]').prop('checked', true);
        }
        if (!$('input[name="pengisian-sikelim"]:checked').length) {
            $('input[name="pengisian-sikelim"][value="Ya"]').prop('checked', true);
        }
        if (!$('input[name="pengisian-dsmiling"]:checked').length) {
            $('input[name="pengisian-dsmiling"][value="Ya"]').prop('checked', true);
        }
        
        // Ensure all 'selects' fields have a value selected (fix for fields that don't get submitted)
        const selectsFields = ['f1001', 'f1003', 'f1004', 'f2002', 'f3001', 'f3002', 'f4001', 'f4002', 'f4005', 'f5002', 'f7001', 'f7002', 'f7003', 'f7004', 'f7005', 'f9002', 'f9003'];
        selectsFields.forEach(function(fieldName) {
            if (!$('input[name="' + fieldName + '"]:checked').length) {
                // Select the first radio button for this field
                $('input[name="' + fieldName + '"]').first().prop('checked', true);
            }
        });
    });
});
</script>

<script src="<?php echo e(asset('js/getDistrictsAndVillages.js')); ?>"></script>
<script src="<?php echo e(asset('js/autosave-form.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dsimfoniku-main\resources\views/pages/inspection/rumah-sakit/create.blade.php ENDPATH**/ ?>