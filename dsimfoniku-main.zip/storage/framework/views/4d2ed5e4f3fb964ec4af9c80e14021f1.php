<?php $__env->startSection('content'); ?>

<div class="p-3 sm:p-6 border-b flex items-center justify-between gap-5">
    <h1 class="font-extrabold sm:text-xl">
        <?php if(auth()->guard()->check()): ?>
            Selamat Datang, <?php echo e(Auth::user()->fullname); ?>

        <?php else: ?>
            Selamat Datang
        <?php endif; ?>
    </h1>
    <img src="<?php echo e(asset('logo/depok-city.png')); ?>" alt="depok city" class="h-6 sm:h-9 object-cover" />
</div>
<div class="grid grid-flow-row md:grid-cols-2 lg:grid-cols-3 gap-5 p-3 sm:p-6">
    <div class="md:col-span-2 bg-white p-3 sm:p-6 rounded-xl">
        <h2 class="font-bold text-lg mb-5">Menu Utama</h2>
        <div class="grid grid-flow-row md:grid-cols-2 gap-5">
            <a href="<?php echo e(route('inspection')); ?>" class="p-6 rounded-lg bg-blue-400 text-white flex items-center gap-2 relative hover:-translate-y-0.5 hover:shadow-sm transition-all">
                <i class="ri-survey-line text-6xl font-bold"></i>
                <div>
                    <h3 class="font-semibold text-xl">18 Form <i class="ri-corner-down-right-line"></i></h3>
                    <p class="text-sm font-medium">Inspeksi Lingkungan Kesehatan</p>
                </div>
            </a>
            <a href="<?php echo e(route('history')); ?>" class="p-6 rounded-lg bg-blue-50 text-blue-500  flex items-center gap-2 relative hover:-translate-y-0.5 hover:shadow-sm transition-all">
                <i class="ri-article-line text-6xl font-bold"></i>
                <div>
                    <h3 class="font-semibold text-xl"><?php echo e($total_results); ?> Hasil <i class="ri-corner-down-right-line"></i></h3>
                    <p class="text-sm">Inspeksi Lingkungan Kesehatan</p>
                </div>
            </a>
        </div>
    </div>
    <div class="md:col-span-2 lg:col-span-1 bg-white p-3 sm:p-6 flex flex-col gap-1 justify-between rounded-xl">
        <h2 class="font-bold text-lg mb-5">Total Inspeksi <span class="text-xs font-base">/ Tahun</span></h2>

        <div class="flex items-end gap-5 p-6 rounded-lg bg-stone-50 pt-8">
            <?php $__currentLoopData = $total_results_by_year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year => $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="font-black flex items-end gap-1 flex-wrap leading-tight text-3xl sm:text-4xl md:text-5xl <?php echo e(!$loop->first ? 'text-gray-400' : ''); ?>"><?php echo e($total); ?><span class="text-sm md:text-base font-medium text-gray-400"><?php echo e($year); ?></span></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>


    <div class="md:col-span-2 lg:col-span-3 bg-white p-3 sm:p-6 rounded-xl">

        <h2 class="font-bold text-lg mb-5">Hasil Inspeksi Terakhir</h2>
        <div class="grid grid-flow-row md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-5">
            <?php $__currentLoopData = $inspections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inspection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <a href="<?php echo e(url($inspection['sud'])); ?>" class="p-6 bg-neutral-100 rounded-lg relative hover:-translate-y-1 hover:shadow-md transition-all col-span-1 <?php echo e($loop->last ? 'lg:col-span-2 xl:col-span-1' : ''); ?>">
                <div class="flex items-center gap-2">
                    <i class="<?php echo e($inspection['icon']); ?> text-<?php echo e($inspection['color']); ?> text-lg"></i>
                    <p class="text-xs"><?php echo e($inspection['title']); ?></p>
                </div>

                <h3 class="font-semibold mt-2"><?php echo e($inspection['name']); ?></h3>
                <p class="text-sm line-clamp-2"><?php echo e($inspection['address']); ?></p>
                <button class="btn btn-xs btn-neutral mt-2"><span>Lihat Detail</span> <i class="ri-arrow-right-line"></i></button>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dsimfoniku-main\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>