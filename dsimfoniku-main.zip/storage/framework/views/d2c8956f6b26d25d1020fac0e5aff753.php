<?php echo $__env->make('header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="h-screen flex items-center justify-center">
    <?php echo $__env->yieldContent('content'); ?>
</div>

<?php echo $__env->make('footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dsimfoniku-main\resources\views/layouts/single.blade.php ENDPATH**/ ?>