<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['form_data']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['form_data']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $data = $form_data['instansi-pemeriksa'] ?? '';
?>

<div class="input-group">
    <label for="instansi-pemeriksa">Instansi Pemeriksa</label>
    <select name="instansi-pemeriksa" id="instansi-pemeriksa" class="select select-bordered" required onchange="toggleInstansiLainnyaEdit()">
        <option value="" disabled>Pilih Instansi Pemeriksa</option>
        <option value="Dinas Kesehatan" <?php if($data == 'Dinas Kesehatan'): ?> selected <?php endif; ?>>Dinas Kesehatan</option>
        <option value="Puskesmas" <?php if($data == 'Puskesmas'): ?> selected <?php endif; ?>>Puskesmas</option>
        <option value="Lainnya" <?php if(!in_array($data, ['Dinas Kesehatan', 'Puskesmas', '']) && $data != ''): ?> selected <?php endif; ?>>Lainnya</option>
    </select>
</div>

<!-- Input manual untuk instansi lainnya -->
<div class="input-group" id="instansi-lainnya-group-edit" style="display: <?php echo e(!in_array($data, ['Dinas Kesehatan', 'Puskesmas', '']) && $data != '' ? 'block' : 'none'); ?>;">
    <label for="instansi-lainnya-edit">Nama Instansi Lainnya</label>
    <input type="text" id="instansi-lainnya-edit" name="instansi-lainnya" class="input input-bordered w-full" placeholder="Masukkan nama instansi" value="<?php echo e(!in_array($data, ['Dinas Kesehatan', 'Puskesmas', '']) ? $data : ''); ?>" />
</div>

<script>
function toggleInstansiLainnyaEdit() {
    const select = document.getElementById('instansi-pemeriksa');
    const lainnyaGroup = document.getElementById('instansi-lainnya-group-edit');
    const lainnyaInput = document.getElementById('instansi-lainnya-edit');
    
    if (select.value === 'Lainnya') {
        lainnyaGroup.style.display = 'block';
        lainnyaInput.required = true;
    } else {
        lainnyaGroup.style.display = 'none';
        lainnyaInput.required = false;
        lainnyaInput.value = '';
    }
}
</script>
<?php /**PATH C:\xampp\htdocs\dsimfoniku-main\resources\views/components/input/instansi-pemeriksa/edit.blade.php ENDPATH**/ ?>