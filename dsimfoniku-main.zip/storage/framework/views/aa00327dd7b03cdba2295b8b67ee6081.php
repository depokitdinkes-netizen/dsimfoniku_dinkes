<div class="p-3 sm:p-6 border-b flex items-center justify-between gap-5">
    <h1 class="font-extrabold sm:text-xl"><?php echo e($title); ?></h1>
    <img src="<?php echo e(asset('logo/depok-city.png')); ?>" alt="depok city" class="h-6 sm:h-9 object-cover" />
</div><?php /**PATH C:\xampp\htdocs\dsimfoniku-main\resources\views/components/section/page-header.blade.php ENDPATH**/ ?>